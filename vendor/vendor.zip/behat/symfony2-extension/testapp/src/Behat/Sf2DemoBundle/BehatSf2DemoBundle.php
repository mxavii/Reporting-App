<?php

namespace Behat\Sf2DemoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BehatSf2DemoBundle extends Bundle
{
}
