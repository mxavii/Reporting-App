<?php
require_once __DIR__ . '/../' . basename(__FILE__);
