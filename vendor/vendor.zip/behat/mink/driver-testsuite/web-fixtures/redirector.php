<?php

header('location: redirect_destination.html');
